#ifndef DETECTION_SKYJO_H_INCLUDED
#define DETECTION_SKYJO_H_INCLUDED

void detection_skyjo (int nb_jr, S_joueur jr[]);

#endif // DETECTION_SKYJO_H_INCLUDED
